﻿using aspnet_config.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

namespace aspnet_config.Controllers
{
    public class HomeController : Controller
    {

        private ApplicationContext db;
        private IWebHostEnvironment _app;

        public HomeController(ApplicationContext context, IWebHostEnvironment app)
        {
            db = context;
            _app = app;
        }

        
        public async Task<IActionResult> Index()
        {
            ViewBag.Email = HttpContext.Session.GetString("Email");
            return View(await db.Users.ToListAsync());
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(User user)
        {
            db.Users.Add(user);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Details(int? id)
        {
                User user = await db.Users.FirstOrDefaultAsync(p => p.Id_User == id);
                return View(user);
        }

        public async Task<IActionResult> FindProfile(string SearchString)
        {
            var origins = from m in db.Users select m;
            if (!String.IsNullOrEmpty(SearchString))
            {
                TestClass.TestStr = SearchString;
                origins = origins.Where(s => s.Login_User.Contains(SearchString));
            }
            return View(await origins.ToListAsync());
        }

        [HttpGet]
        [ActionName("Delete")]
        public async Task<IActionResult> ConfirmDelete(int? id)
        {
            if (id != null)
            {
                User user = await db.Users.FirstOrDefaultAsync(p => p.Id_User == id);
                if (user != null)
                    return View(user);
            }
            return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id != null)
            {
                User user = new User { Id_User = id.Value };
                db.Entry(user).State = EntityState.Deleted;
                await db.SaveChangesAsync();
                return RedirectToAction("ProfileShow");
            }
            return NotFound();
        }

        public async Task<IActionResult> EditProfile(int? id)
        {
            if (id != null)
            {
                User user = await db.Users.FirstOrDefaultAsync(p => p.Id_User == id);
                if (user != null)
                    return View(user);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> EditProfile(User user)
        {
            db.Users.Update(user);
            await db.SaveChangesAsync();
            return RedirectToAction("ProfileShow");
        }

        public IActionResult ProfileShow()
        {
            var model = new UserPost
            {
                Posts = db.Posts.ToList(),
                Users = db.Users.ToList()
            };
            return View(model);
        }

        public IActionResult CreatePost()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> CreatePost(Post post, IFormFile file)
        {
                string path = "/files/" + file.FileName;
                using (var fileStream = new FileStream(_app.WebRootPath + path, FileMode.Create))
                {
                    await file.CopyToAsync(fileStream);
                }
                post.Photo = path;
            post.Owner_Post = TestClass.TestInt;
            db.Posts.Add(post);
            await db.SaveChangesAsync();
            return RedirectToAction("ProfileShow");
        }

        public async Task<IActionResult> DetailsProfilePost(int? id)
        {
            TestClass.TestOwner = (int)id;
            return View(await db.Posts.ToListAsync());
        }

        [HttpGet]
        [ActionName("DeletePost")]
        public async Task<IActionResult> ConfirmDeletePost(int? id)
        {
            if (id != null)
            {
                Post post = await db.Posts.FirstOrDefaultAsync(p => p.Id_Post == id);
                if (post != null)
                    return View(post);
            }
            return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> DeletePost(int? id)
        {
            if (id != null)
            {
                Post post = new Post { Id_Post = id.Value };
                db.Entry(post).State = EntityState.Deleted;
                await db.SaveChangesAsync();
                return RedirectToAction("ProfileShow");
            }
            return NotFound();
        }

        public async Task<IActionResult> EditPost(int? id)
        {
            if (id != null)
            {
                Post post = await db.Posts.FirstOrDefaultAsync(p => p.Id_Post == id);
                if (post != null)
                    return View(post);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> EditPost(Post post)
        {
            db.Posts.Update(post);
            await db.SaveChangesAsync();
            return RedirectToAction("ProfileShow");
        }

        public async Task<IActionResult> Posts()
        {
            return View(await db.Posts.ToListAsync());
        }
    }
}