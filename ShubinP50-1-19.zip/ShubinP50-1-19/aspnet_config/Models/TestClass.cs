﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace aspnet_config.Models
{
    public class TestClass
    {
        public static int TestInt = 0;
        public static string TestStr = "";
        public static int TestOwner = 0;
    }
}
